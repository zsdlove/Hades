package com.moresc.cn;

public class base {
    public static String getHttpRequests(){
        return "requests";
    }
    public static String responseToClient(String p1){
        return "response";
    }
}
