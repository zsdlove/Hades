import com.moresc.cn.base;
/*
* sink点封装
* */
public class Main {
    public static void response(String reqInfo){
        System.out.println(base.responseToClient(reqInfo));
    }
    public static void main(String[] args) {
        String reqInfo=base.getHttpRequests();
        response(reqInfo);
    }
}
