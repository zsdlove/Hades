package com.moresc.cn;

public class base {
    public String getHttpRequests(){
        return "requests";
    }
    public String responseToClient(String p1){
        return "response";
    }
}
