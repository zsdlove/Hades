import com.moresc.cn.base;
public class Main {

    public static void main(String[] args) {
        base bs=new base();
        String reqInfo=bs.getHttpRequests();
        System.out.println(bs.responseToClient(reqInfo));
    }
}
