package moresec;

public class test {
    public String say(){
        System.out.println("hello test.");
        return "hello test";
    }
    public void fuckyou(){
        if("1".equals("1")){
            System.out.println("true");
        }
    }
    public void titan(String nice){
        nice="hello world";
        System.out.println(nice);
    }
}
