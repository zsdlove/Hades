package mylove;

public class base {
    public static void test_func1(String p1,String p2){
        if(p1.equals("nicejob")){
            System.out.println("bingo");
            System.out.println(p2);
        }
        else if(p1.equals("badjob")){
            System.out.println("fuck you");
        }
        else{
            System.out.println("unkown");
        }
    }
}
