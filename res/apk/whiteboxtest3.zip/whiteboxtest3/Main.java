import mylove.*;
import moresec.*;
public class Main {

    public static String test_func2(){
        String love="beautiful girl";
        return love;
    }
    public static void main(String[] args) {
        System.out.println(test_func2());
        base.test_func1("test1","test2");
        base.test_func1("nicejob","test2");
        test t1=new test();
        t1.fuckyou();
        System.out.println(t1.say());
        String input="sunny";
        t1.titan(input);
    }
}
